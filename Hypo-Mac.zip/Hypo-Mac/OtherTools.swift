
import Cocoa

class OtherTools: NSViewController {
    let process = ProcessInfo()
    var task1 = Process()
    var task2 = Process()
    var task3 = Process()
    var task4 = Process()
    var task5 = Process()
    var task6 = Process()
    var task7 = Process()
    var task8 = Process()
    var task9 = Process()
    var task10 = Process()
    var task11 = Process()
    var task12 = Process()
    @IBAction func MacTracker(_ sender: AnyObject) {
        let urlM  = URL(fileURLWithPath: workSpace.fullPath(forApplication: "Mactracker")!)
        workSpace.open(urlM)
    }
    @IBOutlet weak var version: NSTextField!
       @IBAction func print_unin(_ sender: AnyObject) {
        task1.launchPath = "/bin/bash"
        task1.arguments = ["-c", "open /Volumes/STS*/Mac_Stimpak/\"Remove-Popups-MacOS.pkg\""]
        task1.launch()
        task1.waitUntilExit()
    }
    @IBAction func print_install(_ sender: AnyObject) {
        task2.launchPath = "/bin/bash"
        task2.arguments = ["-c", "open /Volumes/STS*/Mac_Stimpak/EaglePrint.pkg"]
        task2.launch()
        task2.waitUntilExit()
    }
    @IBAction func permissions(_ sender: AnyObject) {
        task12.launchPath = "/bin/bash"
        task12.arguments = ["-c", "diskutil repairPermissions /"]
        task12.launch()
        task12.waitUntilExit()
    }
    @IBAction func diskInventoryX(_ sender: AnyObject) {
        task3.launchPath = "/bin/bash"
        task3.arguments = ["-c", "open /Volumes/STS*/Mac_Stimpak/\"Disk Inventory X.app\""]
        task3.launch()
        task3.waitUntilExit()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
    }
    
}
