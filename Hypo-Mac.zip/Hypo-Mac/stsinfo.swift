
import Cocoa

class stsinfo: NSViewController {

    
//    @IBOutlet weak var txtsysteminfo: NSTextField!
    
    @IBOutlet weak var txtserial: NSTextField!

    @IBOutlet weak var txtdiskinfo: NSTextField!

    @IBOutlet weak var txtnet1: NSTextField!

    @IBOutlet weak var txtnet2: NSTextField!

    @IBOutlet weak var txtmodelinfo: NSTextField!
    
    @IBOutlet weak var OSVersion: NSTextField!
    
    @IBOutlet weak var bootTime: NSTextField!
    @IBOutlet weak var macAddress: NSTextField!
    
    func executeCMD(_ command : String,label : NSTextField) -> Void{
        let task = Process()
        task.launchPath = "/bin/sh"
        task.arguments = ["-c",command]
        
        let pipe = Pipe()
        task.standardOutput = pipe
        task.launch()
        
        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        if let output = NSString(data: data, encoding: String.Encoding.utf8.rawValue) {
            print(output)
            label.stringValue = output as String
        }
        
        task.waitUntilExit()
        let status = task.terminationStatus
        print(status)
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let serial_no_command = " system_profiler SPHardwareDataType | awk '/Serial/ {print $4}' ";
        let model_info_command = "curl -s http://support-sp.apple.com/sp/product?cc=`system_profiler SPHardwareDataType | awk '/Serial/ {print $4}' | cut -c 9-` | sed 's|.*<configCode>\\(.*\\)</configCode>.*|\\1|' ";
        let system_info_command = "system_profiler SPSoftwareDataType"
        
        let diskinfo_command = "df -H"
        
        let net1_command = "networksetup -getairportnetwork en0 "
        let net2_command = "networksetup -getinfo Wi-Fi"
        let OS_command = "sw_vers -productVersion"
        let bTime_command = "uptime"
        let macAddress_command = "ifconfig en0 | awk '/ether/{print $2}'"
        executeCMD(serial_no_command,label : txtserial)
        executeCMD(model_info_command,label : txtmodelinfo)
        
//        executeCMD(system_info_command, label: txtsysteminfo)
        
        executeCMD(diskinfo_command, label: txtdiskinfo)
        
        executeCMD(net1_command, label: txtnet1)
        
        executeCMD(net2_command, label: txtnet2)
        
        executeCMD(OS_command, label: OSVersion)
        
        executeCMD(bTime_command, label: bootTime)
        
        executeCMD(macAddress_command, label: macAddress)
        // Do any additional setup after loading the view.
        
    }
    
    override var representedObject: Any? {
        didSet {
            // Update the view, if already loaded.
        }
    }

}
